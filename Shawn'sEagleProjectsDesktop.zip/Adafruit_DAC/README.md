# Adafruit-MCP4725-PCB
PCB files for Adafruit MCP4725 12-Bit DAC Breakout

These are the Eagle CAD files for the Adafruit MCP4725 12-Bit DAC Breakout:

  * https://www.adafruit.com/products/935

Adafruit invests time and resources providing this open source design, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Designed by Limor Fried/Ladyada for Adafruit Industries.
Creative Commons Attribution/Share-Alike, all text above must be included in any redistribution